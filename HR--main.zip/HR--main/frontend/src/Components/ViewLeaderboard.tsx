import React from "react";

const ViewLeaderboard: React.FC = () => {
  return (
    <div>
      <h1>View LeaderBoard</h1>
      <p>This is the LeaderBoard page.</p>
    </div>
  );
};

export default ViewLeaderboard;

import React from "react";

const ViewSalary: React.FC = () => {
  return (
    <div>
      <h1>View Salary</h1>
      <p>This is the Salary page.</p>
    </div>
  );
};

export default ViewSalary;

namespace WebApplication1.DTOs
{
    public class ResendEmailDTO
    {
        public string? Email { get; set; }
    }
}

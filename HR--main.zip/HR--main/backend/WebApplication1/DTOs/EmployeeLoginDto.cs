namespace WebApplication1.DTOs
{

    public class EmployeeLoginDto
    {
        public string EmployeeIdentifier { get; set; } = string.Empty;
        public string Password { get; set; } = string.Empty;
    }
}

namespace WebApplication1.DTOs
{
    public class ForgotPasswordDTO
    {
        public string? Email  { get; set; }
    }
}

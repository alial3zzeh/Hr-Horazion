namespace WebApplication1.DTOs
{
    public class HRUpdateDto
    {
        public string FullName { get; set; } = string.Empty; //HR's full name
        public string PhoneNumber { get; set; } = string.Empty; //HR's phone number
    }
}
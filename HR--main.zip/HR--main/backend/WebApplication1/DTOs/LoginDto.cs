public class LoginDTO
{
    public string? Identifier { get; set; } //Email for HR, Employee ID for Employees
    public string? Password { get; set; }
}
